NB: The .zip file does NOT contain the STAPL file in this folder. This needs to
be re-exported using Libero's "Export Bitstream" feature (see Wiki).

