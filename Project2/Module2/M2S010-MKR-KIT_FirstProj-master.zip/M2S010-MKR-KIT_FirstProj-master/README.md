## Getting started project for M2S010-MKR-KIT

This repository contains all files needed to run the Getting Started project
described on the Wiki page:

- [M2S010-MKR-KIT First Project Wiki](https://github.com/tstana/M2S010-MKR-KIT_FirstProj/wiki)

## How the repository is organised

- `firmware/` folder: MSS support files generated from Libero
- `Libero/` folder: contains the Libero project files in .zip archives
- C project files (for the MSS) are under the main tree of the repository.
