#ifndef test_system_HW_PLATFORM_H_
#define test_system_HW_PLATFORM_H_
/*****************************************************************************
*
*Created by Microsemi SmartDesign  Tue Aug 28 12:22:23 2018
*
*Memory map specification for peripherals in test_system
*/

/*-----------------------------------------------------------------------------
* CM3 subsystem memory map
* Master(s) for this subsystem: CM3 
*---------------------------------------------------------------------------*/


#endif /* test_system_HW_PLATFORM_H_*/
