Export Firmware README

Microsemi Corporation - Microsemi Libero Software Release v11.9 (Version 11.9.0.4)

Date    :    Tue Aug 28 12:22:23 2018
Project :    D:\Projects\cubes\M2S010-MKR-KIT_FirstProj
